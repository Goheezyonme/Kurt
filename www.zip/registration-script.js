        function toggleDropdownVenue() {
            var content = document.getElementById("dropdownContentVenue");
            var arrow = document.getElementById("arrowVenue");

            content.classList.toggle("show");
            arrow.classList.toggle("arrow-down");
            arrow.classList.toggle("arrow-right");
        }
		
		function toggleDropdownEntertainer() {
            var content = document.getElementById("dropdownContentEntertainer");
            var arrow = document.getElementById("arrowEntertainer");

            content.classList.toggle("show");
            arrow.classList.toggle("arrow-down");
            arrow.classList.toggle("arrow-right");
        }
		
		function toggleDropdownFoodTruck() {
            var content = document.getElementById("dropdownContentFoodTruck");
            var arrow = document.getElementById("arrowFoodTruck");

            content.classList.toggle("show");
            arrow.classList.toggle("arrow-down");
            arrow.classList.toggle("arrow-right");
        }
		
		function toggleDropdownCatering() {
            var content = document.getElementById("dropdownContentCatering");
            var arrow = document.getElementById("arrowCatering");

            content.classList.toggle("show");
            arrow.classList.toggle("arrow-down");
            arrow.classList.toggle("arrow-right");
        }
		
		function toggleDropdownTransportation() {
            var content = document.getElementById("dropdownContentTransportation");
            var arrow = document.getElementById("arrowTransportation");

            content.classList.toggle("show");
            arrow.classList.toggle("arrow-down");
            arrow.classList.toggle("arrow-right");
        }
		
		function toggleDropdownAccomodations() {
            var content = document.getElementById("dropdownContentAccomodations");
            var arrow = document.getElementById("arrowAccomodations");

            content.classList.toggle("show");
            arrow.classList.toggle("arrow-down");
            arrow.classList.toggle("arrow-right");
        }