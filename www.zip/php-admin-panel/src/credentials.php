<?php
$local_servername = "localhost";
$local_username = "root";
$local_password = "mysql";